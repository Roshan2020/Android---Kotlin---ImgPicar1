package com.example.imgpicar1

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import com.example.imgpicar1.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    var binding: ActivityMainBinding? = null
    var imgSelected = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding!!.root)
        binding!!.btnImg.setOnClickListener{
            startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), imgSelected)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK){
            if(requestCode == imgSelected){
                binding!!.imgView.setImageBitmap(data!!.extras!!.get("data") as Bitmap)
//                var uri = data!!.data
//                if (uri != null){
//                    binding!!.imgView.setImageURI(uri)
//                }
            }
        }
    }
}